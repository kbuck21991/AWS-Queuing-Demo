# Queuing Demo for V8

This is an example repository to ingest data from the World Coin Index API and display it on a web application.

This solution utilizes AWS Lambda, SQS, RDS, and EC2, to ingest the data, put it on a queue, read that queue and put into a Relational Database before finally displaying via a web app.
