#config file containing credentials for rds sql server instance
db_username = "dbadmin"
db_password = "pv9C16112%3v01a"
db_name = "wci_data" 
