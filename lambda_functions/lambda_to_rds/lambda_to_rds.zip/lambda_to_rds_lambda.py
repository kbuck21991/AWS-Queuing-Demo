import boto3
import sys
import rds_config
import pymysql
from decimal import Decimal
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

rds_host  = "hddbmysql01.cls0ucqv4nms.us-east-2.rds.amazonaws.com"
rds_username = rds_config.db_username
rds_password = rds_config.db_password
rds_db_name = rds_config.db_name



try:
    conn = pymysql.connect(rds_host, user=rds_username, passwd=rds_password, db=rds_db_name, connect_timeout=5)
    logger.info("Connection Established")
except Exception as e:
    logger.info("Error Establishing Connection to Database. Error Details => " + repr(e))
    sys.exit()

#lambda function for enqueing API data from World Coin Index to SQS
def lambda_to_rds_handler(event, context):

    with conn.cursor() as cur:
        for coin in event["Markets"]:
            cur.execute('insert into wci_coindata (Label, Name, Price, Volume, Timestamp) values("'+coin["Label"]+'","'+coin["Name"]+'", "'+str(Decimal(coin["Price"]))+'", "'+str(Decimal(coin["Volume_24h"]))+'", "'+str(coin["Timestamp"])+'") ')
        conn.commit()

    logger.info("Inserted New Coin Data to RDS Successfully.")
